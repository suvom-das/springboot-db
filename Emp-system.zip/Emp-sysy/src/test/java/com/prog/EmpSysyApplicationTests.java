package com.prog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpSysyApplicationTests {

	@Test
	void contextLoads() {
	}

}
